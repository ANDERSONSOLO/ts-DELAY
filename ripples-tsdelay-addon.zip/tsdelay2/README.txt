Аддон к Ripples of the Past (Forge 1.16.5, forge 36.2.34, Java 8).
Сборка: залей содержимое папки в репозиторий GitHub -> Actions -> build -> Run workflow -> скачай jar из Artifacts.
Локально: JDK 8 + `gradle wrapper --gradle-version 7.6.4`, затем `./gradlew build` -> build/libs/
Установка: положи jar в mods рядом с Ripples of the Past (и его зависимостями playerAnimator, bendy-lib).
