package com.example.tsdelay;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.forgespi.language.IModFileInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

@Mod(TsDelay.MODID)
public class TsDelay {
    public static final String MODID = "tsdelay";
    private static final Logger LOG = LogManager.getLogger();

    /** Накопленный урон по мобам, замороженным остановкой времени. */
    private static final Map<LivingEntity, Pending> PENDING = new WeakHashMap<>();
    private static boolean replaying = false;

    private static class Pending {
        float total;
        DamageSource source;
    }

    public TsDelay() {
        MinecraftForge.EVENT_BUS.register(TsDelay.class);
    }

    /** Удар по мобу в остановленном времени: отменяем и копим в счётчик. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttack(LivingAttackEvent e) {
        LivingEntity target = e.getEntityLiving();
        if (target.level.isClientSide || replaying) return;
        if (target instanceof PlayerEntity) return; // только мобы
        if (e.getAmount() <= 0) return;
        if (!isFrozen(target)) return;

        Pending p = PENDING.get(target);
        if (p == null) { p = new Pending(); PENDING.put(target, p); }
        p.total += e.getAmount();
        p.source = e.getSource();
        e.setCanceled(true);

        Entity attacker = e.getSource().getEntity();
        if (attacker instanceof ServerPlayerEntity) {
            ((ServerPlayerEntity) attacker).displayClientMessage(new StringTextComponent(
                    "\u23F1 " + target.getName().getString() + ": накоплено "
                            + String.format("%.1f", p.total) + " HP"), true);
        }
    }

    /** Время пошло — наносим весь накопленный урон одним ударом. */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || PENDING.isEmpty()) return;

        for (Map.Entry<LivingEntity, Pending> en : new ArrayList<>(PENDING.entrySet())) {
            LivingEntity t = en.getKey();
            Pending p = en.getValue();
            if (t == null || !t.isAlive()) { PENDING.remove(t); continue; }
            if (isFrozen(t)) continue;

            PENDING.remove(t);
            replaying = true;
            try {
                t.invulnerableTime = 0;
                t.hurt(p.source, p.total);
            } finally {
                replaying = false;
            }
        }
    }

    // ---------- связь с Ripples of the Past через reflection ----------
    private static Method check;
    private static int mode = 0; // 1: (World, ChunkPos)  2: (World, BlockPos)  3: (Entity)
    private static boolean searched = false;

    private static boolean isFrozen(Entity entity) {
        if (!searched) { searched = true; findCheckMethod(); }
        if (check == null) return false;
        try {
            Object r;
            if (mode == 1) r = check.invoke(null, entity.level, new ChunkPos(entity.blockPosition()));
            else if (mode == 2) r = check.invoke(null, entity.level, entity.blockPosition());
            else r = check.invoke(null, entity);
            return Boolean.TRUE.equals(r);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Ищем в jar мода статический метод вида isTimeStopped(...) в классах *TimeStop* / *TimeUtil*. */
    private static void findCheckMethod() {
        try {
            IModFileInfo info = null;
            for (String id : new String[]{"jojo", "ripplesofthepast", "ripples_of_the_past"}) {
                info = ModList.get().getModFileById(id);
                if (info != null) break;
            }
            if (info == null) { LOG.error("[tsdelay] Мод Ripples of the Past не найден."); return; }
            Path path = info.getFile().getFilePath();
            if (!Files.isRegularFile(path)) { LOG.error("[tsdelay] Запуск из папки, не из jar - поиск не поддержан."); return; }

            Method best = null; int bestMode = 0;
            try (JarFile jar = new JarFile(path.toFile())) {
                Enumeration<JarEntry> en = jar.entries();
                while (en.hasMoreElements()) {
                    String n = en.nextElement().getName();
                    if (!n.endsWith(".class")) continue;
                    String simple = n.substring(n.lastIndexOf('/') + 1);
                    if (!simple.contains("TimeStop") && !simple.contains("TimeUtil")) continue;
                    Class<?> c;
                    try {
                        c = Class.forName(n.substring(0, n.length() - 6).replace('/', '.'), false, TsDelay.class.getClassLoader());
                    } catch (Throwable t) { continue; }
                    Method[] ms;
                    try { ms = c.getDeclaredMethods(); } catch (Throwable t) { continue; }
                    for (Method m : ms) {
                        if (!Modifier.isStatic(m.getModifiers()) || m.getReturnType() != boolean.class) continue;
                        if (!m.getName().toLowerCase().contains("istimestopped")) continue;
                        Class<?>[] pt = m.getParameterTypes();
                        int md = 0;
                        if (pt.length == 2 && pt[0] == World.class && pt[1] == ChunkPos.class) md = 1;
                        else if (pt.length == 2 && pt[0] == World.class && pt[1] == BlockPos.class) md = 2;
                        else if (pt.length == 1 && pt[0].isAssignableFrom(Entity.class) && pt[0] != Object.class) md = 3;
                        if (md != 0 && (best == null || md < bestMode)) { best = m; bestMode = md; }
                    }
                }
            }
            if (best != null) {
                best.setAccessible(true);
                check = best; mode = bestMode;
                LOG.info("[tsdelay] Проверка тайм-стопа: {}.{} (mode {})", best.getDeclaringClass().getName(), best.getName(), mode);
            } else {
                LOG.error("[tsdelay] Не нашёл метод проверки тайм-стопа в Ripples of the Past. Аддон неактивен - нужно поправить isFrozen().");
            }
        } catch (Throwable t) {
            LOG.error("[tsdelay] Ошибка поиска метода тайм-стопа", t);
        }
    }
}
